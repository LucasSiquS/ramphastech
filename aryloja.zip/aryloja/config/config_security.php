<?php
// config/config_security.php

// Configurações de segurança
define('DB_HOST', 'localhost');
define('DB_NAME', 'aryloja');
define('DB_USER', 'ifhostgru');
define('DB_PASS', 'rl8DHEf)ONT$68ts');

// Opções PDO para máxima segurança
define('PDO_OPTIONS', array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false, // Usar prepared statements nativos
    PDO::ATTR_PERSISTENT => false // Não usar conexões persistentes
));

// Configurações de SESSION
ini_set('session.cookie_httponly', 1); // Evitar acesso JavaScript
ini_set('session.cookie_secure', 0); // Em produção, mudar para 1 com HTTPS
ini_set('session.use_strict_mode', 1);
ini_set('session.name', 'ARYAPP');

// Configurações gerais
define('MAX_LOGIN_ATTEMPTS', 5); // Máximo de tentativas de login
define('LOGIN_TIMEOUT', 300); // 5 minutos em segundos
define('UPLOAD_DIR', __DIR__ . '/../public/uploads/');
define('MAX_UPLOAD_SIZE', 5242880); // 5MB
define('ALLOWED_EXTENSIONS', array('jpg', 'jpeg', 'png', 'gif'));

// Headers de segurança
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');
header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
