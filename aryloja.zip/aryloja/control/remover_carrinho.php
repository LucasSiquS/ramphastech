<?php
if (!isset($_SESSION)) {
    session_start();
}

$index = $_POST['index'] ?? null;

if ($index !== null) {
    unset($_SESSION['carrinho'][$index]);
}

// Redirecionar de volta ao carrinho
header('Location: /aryloja/public/carrinho.php');
exit;
