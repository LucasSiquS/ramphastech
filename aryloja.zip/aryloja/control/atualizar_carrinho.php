<?php
if (!isset($_SESSION)) {
    session_start();
}

$index = $_POST['index'] ?? null;
$quantidade = (int)($_POST['quantidade'] ?? 0);

if ($index !== null && $quantidade > 0) {
    if (isset($_SESSION['carrinho'][$index])) {
        $_SESSION['carrinho'][$index]['quantidade'] = $quantidade;
    }
}

// Redirecionar de volta ao carrinho
header('Location: /aryloja/public/carrinho.php');
exit;
