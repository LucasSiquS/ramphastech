<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="/aryloja/public/assets/css/index.css">
  <title>Ary Bordados e Costuras Criativas</title>
</head>
<body>
<?php require_once __DIR__ . '/view/helpers/header.php'; ?>
<section class="hero">
  <h1>Ary Bordados e Costuras Criativas</h1>
  <p>Bem-vindo(a) ao meu cantinho, onde a agulha e a linha dançam para transformar sonhos e memórias em peças únicas e cheias de significado.</p>
</section>

<section class="products">
  <h2 class="section-title">Produtos</h2>
  <div id="produtos-grid" class="products-grid"></div>
</section>

<section class="feedbacks">
  <h2 class="section-title">Avaliações e Comentários</h2>
  <div id="feedbacks-container" class="feedbacks-container"></div>
  
  <?php if (isset($_SESSION) && !empty($_SESSION['usuario'])): ?>
  <div class="feedback-form">
    <h3>Deixe seu comentário</h3>
    <form id="feedbackForm" onsubmit="enviarFeedback(event)">
      <textarea 
        id="comentario" 
        name="comentario" 
        placeholder="Digite seu comentário (máximo 300 caracteres)" 
        maxlength="300" 
        required></textarea>
      <div class="feedback-form-footer">
        <span id="charCount">0/300</span>
        <button type="submit" class="btn-enviar">Enviar Comentário</button>
      </div>
    </form>
    <p id="feedback-message" class="feedback-message"></p>
  </div>
  <?php else: ?>
    <div class="feedback-login-request">
      <p>Você precisa <a href="/aryloja/public/login.php">entrar</a> para deixar um comentário e acessar o carrinho.</p>
    </div>
  <?php endif; ?>
</section>

<?php require_once __DIR__ . '/view/helpers/footer.php'; ?>



</body>
<script src="/aryloja/public/assets/js/public.js"></script>
<script src="/aryloja/public/assets/js/app.js"></script>
</html>

