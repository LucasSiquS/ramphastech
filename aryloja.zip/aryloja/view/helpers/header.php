<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ary Bordados e Costuras Criativas</title>
    <link rel="stylesheet" href="/aryloja/public/assets/css/style.css">
    <link rel="icon" href="/aryloja/public/assets/img/logoarybordados.jpeg">
    <?php
    if (!isset($_SESSION)) {
        session_start();
    }
    // Garantir que exista um CSRF token na sessão para formulários/AJAX
    if (empty($_SESSION['csrf_token'])) {
        try {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        } catch (Exception $e) {
            // fallback simples
            if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(openssl_random_pseudo_bytes(32));
        }
    }
    ?>
    <meta name="csrf-token" content="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
</head>
<body>

<!-- Navbar -->
<header class="navbar">
    <a href="/aryloja/index.php" class="navbar-brand">Ary Bordados e Costuras Criativas</a>
    <nav>
        <ul>
            <li><a href="/aryloja/index.php">Home</a></li>
            <li><a href="/aryloja/public/carrinho.php">Carrinho</a></li>
            <?php
            if (!isset($_SESSION)) {
                session_start();
            }
            if(isset($_SESSION['usuario'])):
                if($_SESSION['usuario']['permissao'] === 'admin'): ?>
                    <li><a href="/aryloja/public/admin.php">Admin</a></li>
                <?php endif; ?>
                <li><span class="user-welcome">Olá, <?php echo htmlspecialchars(explode(' ', $_SESSION['usuario']['nome'])[0]); ?>!</span></li>
                <li><a href="/aryloja/app/routes/logout.php" class="btn-logout">Sair</a></li>
            <?php else: ?>
                <li><a href="/aryloja/public/login.php" class="btn-login">Login</a></li>
            <?php endif; ?>
        </ul>
    </nav>
</header>

<?php
// Mostrar jumbotron apenas na index (não no login nem no carrinho)
$current_page = basename($_SERVER['PHP_SELF']);
if ($current_page === 'index.php'):
?>
<section class="jumbotron">
    <div class="jumbotron-text">
        <h2>Costuras criativas e bordados personalizados para você!</h2>
        <p>Explore nossa coleção e encontre peças únicas feitas com carinho.</p>
    </div>
    <img src="/aryloja/public/assets/img/logoarybordados.jpeg" alt="Logo Ary Bordados" class="jumbotron-img">
</section>
<?php else: ?>
<hr style="margin: 2rem 0;">
<?php endif; ?>