<footer>
    <p>&copy; 2025 Ary Bordados e Costuras Criativas</p>
    <p><a href="https://www.instagram.com/ary_bordadosgr/#" >Instagram</a></p>
    <img src="/aryloja/public/assets/img/insta.png" alt="instagram" style="width:24px;height:24px;">
</footer>
</body>
</html>