
<?php
require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../models/Feedback.php';

class FeedbackController {
    private $model;

    public function __construct() {
        $this->model = new Feedback();
    }

    public function listar() {
        return $this->model->listarTodos();
    }

    public function salvar($dados, $usuario = null) {
        $comentario = $dados['comentario'] ?? '';
        $comentario = trim($comentario);

        if ($comentario === '') {
            return ['success' => false, 'error' => 'Comentário não pode estar vazio.'];
        }
        if (mb_strlen($comentario) > 300) {
            return ['success' => false, 'error' => 'Comentário excede 300 caracteres.'];
        }

        $usuario_id = null;
        if (!empty($usuario) && is_array($usuario)) {
            $usuario_id = $usuario['id'] ?? $usuario['id_usuario'] ?? null;
        }

        $ok = $this->model->salvar($comentario, $usuario_id);
        return ['success' => $ok];
    }

    public function excluir($id) {
        if (!is_numeric($id)) {
            return ['success' => false, 'error' => 'ID inválido'];
        }
        $ok = $this->model->excluir((int)$id);
        return ['success' => $ok];
    }
}
