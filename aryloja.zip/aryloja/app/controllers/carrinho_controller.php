<?php
// app/controllers/carrinho_controller.php
require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../models/Carrinho.php';

class CarrinhoController {
    private $carrinhoModel;

    public function __construct() {
        $pdo = Database::getInstance();
        $this->carrinhoModel = new Carrinho($pdo);
    }

    public function adicionarProduto($id, $quantidade = 1) {
        return $this->carrinhoModel->adicionarProduto($id, $quantidade);
    }

    public function removerProduto($id) {
        return $this->carrinhoModel->removerProduto($id);
    }

    public function listarItens() {
        return $this->carrinhoModel->listarItens();
    }

    public function calcularTotal() {
        return $this->carrinhoModel->calcularTotal();
    }

    public function limparCarrinho() {
        return $this->carrinhoModel->limparCarrinho();
    }
}
