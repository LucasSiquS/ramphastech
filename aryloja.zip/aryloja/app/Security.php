<?php
// app/models/Security.php

class Security {
    // Gerar CSRF Token
    public static function gerarToken() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
    
    // Verificar CSRF Token
    public static function verificarToken($token) {
        if (!isset($_SESSION['csrf_token'])) {
            return false;
        }
        
        return hash_equals($_SESSION['csrf_token'], $token);
    }
    
    // Rate limiting (proteção contra força bruta)
    public static function verificarRateLimiting($chave, $limite = 5, $tempo = 300) {
        $chave_rate = "rate_limit_" . $chave;
        
        if (!isset($_SESSION[$chave_rate])) {
            $_SESSION[$chave_rate] = ['tentativas' => 0, 'primeira_tentativa' => time()];
        }
        
        $dados = $_SESSION[$chave_rate];
        $tempo_passado = time() - $dados['primeira_tentativa'];
        
        // Se passou o tempo, resetar
        if ($tempo_passado > $tempo) {
            $_SESSION[$chave_rate] = ['tentativas' => 0, 'primeira_tentativa' => time()];
            return true;
        }
        
        // Se ainda está no limite, aumentar contador
        if ($dados['tentativas'] < $limite) {
            $_SESSION[$chave_rate]['tentativas']++;
            return true;
        }
        
        // Ultrapassou o limite
        return false;
    }
    
    // Registrar tentativa de acesso
    public static function registrarTentativa($tipo, $ip) {
        // Aqui você pode implementar logging em arquivo ou banco de dados
        $log = "Tentativa de $tipo | IP: $ip | Data: " . date('Y-m-d H:i:s') . "\n";
        // error_log($log, 3, "/var/log/seu_app.log");
    }
    
    // Obter IP do cliente
    public static function obterIP() {
        $ip = '';
        
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            // Pegar o primeiro IP da lista se houver múltiplos
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = trim($ips[0]);
        } else {
            $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        }
        
        // Validar se é um IP válido
        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            return $ip;
        }
        
        return 'DESCONHECIDO';
    }
    
    // Sanitizar entrada HTML
    public static function sanitizarHTML($entrada) {
        return htmlspecialchars($entrada, ENT_QUOTES, 'UTF-8');
    }
    
    // Validar se é uma requisição AJAX
    public static function ehAjax() {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }
}
