<?php

if (!isset($_SESSION)) {
    session_start();
}

header('Content-Type: application/json');

try {
    require_once '../controllers/usuario_controller.php';

    $controller = new UsuarioController();
    $acao = $_POST['acao'] ?? '';

    switch ($acao) {
        case 'login':
            $usuario = $controller->login($_POST['email'], $_POST['senha']);
            if ($usuario) {
                $_SESSION['usuario_id'] = $usuario['id_usuario'];
                $_SESSION['usuario_nome'] = $usuario['nome'];
                $_SESSION['usuario_email'] = $usuario['email'];
                $_SESSION['usuario'] = [
                    'id' => $usuario['id_usuario'],
                    'nome' => $usuario['nome'],
                    'email' => $usuario['email'],
                    'permissao' => $usuario['permissao']
                ];
                echo json_encode(['success' => true, 'usuario' => $usuario]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Credenciais inválidas']);
            }
            break;

        case 'cadastrar':
            $resultado = $controller->cadastrar($_POST);
            if ($resultado) {
                echo json_encode(['success' => true, 'message' => 'Cadastro realizado com sucesso!']);
            } else {
                echo json_encode(['success' => false, 'error' => 'Email já existe ou erro ao cadastrar']);
            }
            break;

        default:
            echo json_encode(['error' => 'Ação inválida']);
    }
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

