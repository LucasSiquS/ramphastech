<?php
// app/routes/produto_ajax.php
header('Content-Type: application/json');
require_once '../controllers/produto_controller.php';

$controller = new ProdutoController();

$acao = $_POST['acao'] ?? '';

function fazerUploadImagem($arquivo) {
    if (!isset($arquivo) || $arquivo['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    
    $pastaUpload = __DIR__ . '/../../public/uploads/';
    if (!is_dir($pastaUpload)) {
        mkdir($pastaUpload, 0755, true);
    }
    
    $nomeArquivo = basename($arquivo['name']);
    $nomeUnico = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '_', $nomeArquivo);
    $caminho = $pastaUpload . $nomeUnico;
    
    if (move_uploaded_file($arquivo['tmp_name'], $caminho)) {
        return $nomeUnico;
    }
    
    return null;
}

switch ($acao) {
    case 'cadastrar':
        $dados = $_POST;
        if (isset($_FILES['imagem_file']) && $_FILES['imagem_file']['error'] === UPLOAD_ERR_OK) {
            $nomeImagem = fazerUploadImagem($_FILES['imagem_file']);
            if ($nomeImagem) {
                $dados['imagem'] = $nomeImagem;
            }
        }
        unset($dados['imagem_file']);
        $resultado = $controller->cadastrar($dados);
        echo json_encode(['success' => $resultado]);
        break;

    case 'atualizar':
        $dados = $_POST;
        if (isset($_FILES['imagem_file']) && $_FILES['imagem_file']['error'] === UPLOAD_ERR_OK) {
            $nomeImagem = fazerUploadImagem($_FILES['imagem_file']);
            if ($nomeImagem) {
                $dados['imagem'] = $nomeImagem;
            }
        }
        unset($dados['imagem_file']);
        $resultado = $controller->atualizar($dados);
        echo json_encode(['success' => $resultado]);
        break;

    case 'excluir':
        $resultado = $controller->excluir($_POST['id']);
        echo json_encode(['success' => $resultado]);
        break;

    case 'listar':
        $produtos = $controller->listar();
        echo json_encode($produtos);
        break;

    default:
        echo json_encode(['error' => 'Ação inválida']);
}

