<?php
header('Content-Type: application/json');

if (!isset($_SESSION)) {
    session_start();
}

require_once '../controllers/carrinho_controller.php';

$carrinhoController = new CarrinhoController();
$itens = $carrinhoController->listarItens();
$total = $carrinhoController->calcularTotal();

if (empty($itens)) {
    echo json_encode(['success' => false, 'error' => 'Carrinho vazio']);
    exit;
}

// Formatar mensagem
$mensagem = "🛍️ *NOVO PEDIDO* 🛍️\n\n";
$mensagem .= "*Itens do Pedido:*\n";

foreach ($itens as $id => $item) {
    $quantidade = $item['quantidade'] ?? 1;
    $nome = htmlspecialchars($item['nome'] ?? 'Produto');
    $preco = floatval($item['preco'] ?? 0);
    $subtotal = $preco * $quantidade;
    
    $mensagem .= "• {$nome}\n";
    $mensagem .= "  Quantidade: {$quantidade}x\n";
    $mensagem .= "  Preço: R$ " . number_format($preco, 2, ',', '.') . "\n";
    $mensagem .= "  Subtotal: R$ " . number_format($subtotal, 2, ',', '.') . "\n\n";
}

$mensagem .= "*Total do Pedido:* R$ " . number_format($total, 2, ',', '.') . "\n\n";
$mensagem .= "💳 *Formas de pagamento:* PIX, Cartão de Crédito/Débito ou Dinheiro\n";
$mensagem .= "📦 *Frete e prazo:* A confirmar\n";
$mensagem .= "🎁 *Embalagem:* Especial com carinho\n\n";
$mensagem .= "Obrigado pela compra! 💝";

echo json_encode([
    'success' => true,
    'mensagem' => $mensagem,
    'total' => $total,
    'itens_count' => count($itens)
]);

