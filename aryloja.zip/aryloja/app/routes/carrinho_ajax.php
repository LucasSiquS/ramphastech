<?php

header('Content-Type: application/json');

if (!isset($_SESSION)) {
    session_start();
}

if (!isset($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}

$acao = $_POST['acao'] ?? '';

// Requer login para operações do carrinho
if (empty($_SESSION['usuario'])) {
  echo json_encode(['success' => false, 'error' => 'Você precisa estar logado para acessar o carrinho.']);
  exit;
}

switch ($acao) {
  case 'adicionar':
    $id = $_POST['id_produto'] ?? null;
    $qtd = (int)($_POST['qtd'] ?? 1);
    if ($id) {
      // Buscar dados do produto no BD
      require_once '../../config/Database.php';
      require_once '../models/Produto.php';
      
      $pdo = Database::getInstance();
      $stmt = $pdo->prepare("SELECT * FROM produtos WHERE id_produto = ?");
      $stmt->execute([$id]);
      $dados = $stmt->fetch(PDO::FETCH_ASSOC);
      
      if (!$dados) {
        echo json_encode(['success' => false, 'error' => 'Produto não encontrado']);
        exit;
      }
      
      // Verificar estoque disponível
      $quantidadeAtual = $_SESSION['carrinho'][$id]['quantidade'] ?? 0;
      $quantidadeTotal = $quantidadeAtual + $qtd;
      
      if ($quantidadeTotal > $dados['estoque']) {
        echo json_encode([
          'success' => false, 
          'error' => 'Quantidade não disponível. Máximo em estoque: ' . $dados['estoque'] . ', já no carrinho: ' . $quantidadeAtual
        ]);
        exit;
      }
      
      // Se já existe, aumenta a quantidade
      if (isset($_SESSION['carrinho'][$id])) {
        $_SESSION['carrinho'][$id]['quantidade'] += $qtd;
      } else {
        $_SESSION['carrinho'][$id] = [
          'nome' => $dados['nome'],
          'preco' => $dados['preco'],
          'quantidade' => $qtd,
          'imagem' => $dados['imagem'] ?? null,
          'estoque' => $dados['estoque']
        ];
      }
      echo json_encode(['success' => true, 'message' => 'Produto adicionado ao carrinho']);
    } else {
      echo json_encode(['success' => false, 'error' => 'ID inválido']);
    }
    break;

  case 'atualizar':
    $index = $_POST['index'] ?? null;
    $quantidade = (int)($_POST['quantidade'] ?? 0);
    if ($index !== null && $quantidade > 0) {
      if (isset($_SESSION['carrinho'][$index])) {
        // Verificar estoque
        $estoque = $_SESSION['carrinho'][$index]['estoque'] ?? 999999;
        
        if ($quantidade > $estoque) {
          echo json_encode([
            'success' => false, 
            'error' => 'Quantidade não disponível. Máximo em estoque: ' . $estoque
          ]);
        } else {
          $_SESSION['carrinho'][$index]['quantidade'] = $quantidade;
          echo json_encode(['success' => true]);
        }
      } else {
        echo json_encode(['success' => false, 'error' => 'Item não encontrado']);
      }
    } else {
      echo json_encode(['success' => false, 'error' => 'Dados inválidos']);
    }
    break;

  case 'listar':
    echo json_encode($_SESSION['carrinho']);
    break;

  case 'remover':
    $id = $_POST['id_produto'] ?? null;
    if ($id && isset($_SESSION['carrinho'][$id])) {
      unset($_SESSION['carrinho'][$id]);
      echo json_encode(['success' => true]);
    } else {
      echo json_encode(['success' => false, 'error' => 'ID inválido']);
    }
    break;

  case 'limpar':
    $_SESSION['carrinho'] = [];
    echo json_encode(['success' => true]);
    break;

  case 'total':
    $total = 0;
    foreach ($_SESSION['carrinho'] as $item) {
      $total += $item['preco'] * $item['quantidade'];
    }
    echo json_encode(['total' => $total]);
    break;

  default:
    echo json_encode(['error' => 'Ação inválida']);
}

