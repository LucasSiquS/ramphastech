<?php
if (!isset($_SESSION)) {
    session_start();
}

header('Content-Type: application/json');

// Verificar se é administrador
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['email'] !== 'chefeary@gmail.com') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Acesso negado']);
    exit;
}

function fazerUploadImagem($arquivo) {
    if (!isset($arquivo) || $arquivo['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    
    $pastaUpload = __DIR__ . '/../../public/uploads/';
    if (!is_dir($pastaUpload)) {
        mkdir($pastaUpload, 0755, true);
    }
    
    $nomeArquivo = basename($arquivo['name']);
    $nomeUnico = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '_', $nomeArquivo);
    $caminho = $pastaUpload . $nomeUnico;
    
    if (move_uploaded_file($arquivo['tmp_name'], $caminho)) {
        return $nomeUnico;
    }
    
    return null;
}

try {
    require_once '../controllers/produto_controller.php';
    require_once '../controllers/usuario_controller.php';
    require_once '../controllers/feedback_controller.php';

    $acao = $_POST['acao'] ?? $_GET['acao'] ?? '';
    $tipo = $_POST['tipo'] ?? $_GET['tipo'] ?? '';

    switch ($tipo) {
        case 'produtos':
            $controller = new ProdutoController();
            
            switch ($acao) {
                case 'listar':
                    echo json_encode($controller->listar());
                    break;

                case 'cadastrar':
                    $dados = $_POST;
                    if (isset($_FILES['imagem_file']) && $_FILES['imagem_file']['error'] === UPLOAD_ERR_OK) {
                        $nomeImagem = fazerUploadImagem($_FILES['imagem_file']);
                        if ($nomeImagem) {
                            $dados['imagem'] = $nomeImagem;
                        }
                    }
                    unset($dados['imagem_file']);
                    $resultado = $controller->cadastrar($dados);
                    echo json_encode(['success' => $resultado]);
                    break;

                case 'atualizar':
                    $dados = $_POST;
                    if (isset($_FILES['imagem_file']) && $_FILES['imagem_file']['error'] === UPLOAD_ERR_OK) {
                        $nomeImagem = fazerUploadImagem($_FILES['imagem_file']);
                        if ($nomeImagem) {
                            $dados['imagem'] = $nomeImagem;
                        }
                    }
                    unset($dados['imagem_file']);
                    $resultado = $controller->atualizar($dados);
                    echo json_encode(['success' => $resultado]);
                    break;

                case 'excluir':
                    $resultado = $controller->excluir($_POST['id'] ?? null);
                    echo json_encode(['success' => $resultado]);
                    break;

                default:
                    echo json_encode(['error' => 'Ação inválida']);
            }
            break;

        case 'usuarios':
            $controller = new UsuarioController();
            
            switch ($acao) {
                case 'listar':
                    echo json_encode($controller->listar());
                    break;

                case 'excluir':
                    $resultado = $controller->excluir($_POST['id'] ?? null);
                    echo json_encode(['success' => $resultado]);
                    break;

                default:
                    echo json_encode(['error' => 'Ação inválida']);
            }
            break;

        case 'feedbacks':
            $controller = new FeedbackController();
            
            switch ($acao) {
                case 'listar':
                    echo json_encode($controller->listar());
                    break;

                case 'excluir':
                    $resultado = $controller->excluir($_POST['id'] ?? null);
                    echo json_encode(['success' => $resultado]);
                    break;

                default:
                    echo json_encode(['error' => 'Ação inválida']);
            }
            break;

        case 'dashboard':
            switch ($acao) {
                case 'stats':
                    $produtoCtrl = new ProdutoController();
                    $usuarioCtrl = new UsuarioController();
                    $feedbackCtrl = new FeedbackController();

                    $produtos = $produtoCtrl->listar();
                    $usuarios = $usuarioCtrl->listar();
                    $feedbacks = $feedbackCtrl->listar();

                    echo json_encode([
                        'totalProdutos' => count($produtos),
                        'totalUsuarios' => count($usuarios),
                        'totalFeedbacks' => count($feedbacks)
                    ]);
                    break;

                default:
                    echo json_encode(['error' => 'Ação inválida']);
            }
            break;

        default:
            echo json_encode(['error' => 'Tipo inválido']);
    }

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
