<?php
if (!isset($_SESSION)) {
    session_start();
}

// Destruir sessão
session_destroy();

// Redirecionar para login
header('Location: /aryloja/public/login.php');
exit;
