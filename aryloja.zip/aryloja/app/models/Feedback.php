
<?php
require_once __DIR__ . '/../../config/Database.php';

class Feedback {
    private $pdo;

    public function __construct() {
        $this->pdo = Database::getInstance();
        // Garantir que a coluna usuario_id existe (para associar feedbacks a usuários)
        try {
            $stmt = $this->pdo->prepare("SHOW COLUMNS FROM feedbacks LIKE 'usuario_id'");
            $stmt->execute();
            $col = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$col) {
                $this->pdo->exec("ALTER TABLE feedbacks ADD COLUMN usuario_id INT NULL");
            }
        } catch (Throwable $e) {
            // Se ocorrer erro, não interrompe a aplicação; feedbacks seguirão funcionando sem usuário
        }
    }

    public function listarTodos() {
        // Tentar trazer o nome do usuário se a coluna usuario_id existir
        try {
            $sql = "SELECT f.id, f.comentario, f.data_criacao, u.nome AS usuario_nome FROM feedbacks f LEFT JOIN usuarios u ON f.usuario_id = u.id_usuario ORDER BY f.data_criacao DESC";
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
            $sql = "SELECT id, comentario, data_criacao FROM feedbacks ORDER BY data_criacao DESC";
            $stmt = $this->pdo->query($sql);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    public function salvar($comentario, $usuario_id = null) {
        // Inserir comentário e, quando possível, associar ao usuário
        try {
            if ($usuario_id !== null) {
                $sql = "INSERT INTO feedbacks (comentario, usuario_id) VALUES (?, ?)";
                $stmt = $this->pdo->prepare($sql);
                return $stmt->execute([trim($comentario), $usuario_id]);
            }
        } catch (Throwable $e) {
            // fallback para inserir sem coluna usuario_id
        }

        $sql = "INSERT INTO feedbacks (comentario) VALUES (?)";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([trim($comentario)]);
    }

    public function excluir($id) {
        $sql = "DELETE FROM feedbacks WHERE id=?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([$id]);
    }
}
