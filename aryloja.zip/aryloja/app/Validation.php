<?php
// app/models/Validation.php

class Validation {
    // Validar email
    public static function validarEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    // Validar senha
    public static function validarSenha($senha) {
        return strlen($senha) >= 6 && strlen($senha) <= 255;
    }
    
    // Validar nome
    public static function validarNome($nome) {
        $nome = trim($nome);
        return !empty($nome) && strlen($nome) >= 3 && strlen($nome) <= 100;
    }
    
    // Validar ID (numérico positivo)
    public static function validarId($id) {
        return is_numeric($id) && intval($id) > 0;
    }
    
    // Validar número (positivo)
    public static function validarNumero($numero, $minimo = 0) {
        return is_numeric($numero) && $numero >= $minimo;
    }
    
    // Sanitizar entrada de texto
    public static function sanitizar($texto) {
        return trim(htmlspecialchars($texto, ENT_QUOTES, 'UTF-8'));
    }
    
    // Validar comentário (feedback)
    public static function validarComentario($comentario) {
        $comentario = trim($comentario);
        return !empty($comentario) && strlen($comentario) <= 300 && strlen($comentario) >= 3;
    }
    
    // Validar produto
    public static function validarProduto($nome, $descricao, $preco, $estoque, $categoria) {
        // Nome
        if (empty($nome) || strlen($nome) < 3 || strlen($nome) > 100) {
            return false;
        }
        
        // Descrição
        if (empty($descricao) || strlen($descricao) < 10 || strlen($descricao) > 1000) {
            return false;
        }
        
        // Preço
        if (!is_numeric($preco) || $preco < 0 || $preco > 999999.99) {
            return false;
        }
        
        // Estoque
        if (!is_numeric($estoque) || $estoque < 0 || $estoque > 999999) {
            return false;
        }
        
        // Categoria
        if (empty($categoria) || strlen($categoria) < 2 || strlen($categoria) > 50) {
            return false;
        }
        
        return true;
    }
}