<?php
if (!isset($_SESSION)) {
    session_start();
}

// Verificar se é administrador
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['email'] !== 'chefeary@gmail.com') {
    header('Location: /aryloja/public/login.php');
    exit;
}

// Gerar CSRF token se não existir
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo $_SESSION['csrf_token']; ?>">
    <title>Painel de Administração - Ary Bordados</title>
    <link rel="stylesheet" href="/aryloja/public/assets/css/style.css">
    <link rel="stylesheet" href="/aryloja/public/assets/css/admin_dashboard.css">
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar -->
        <aside class="admin-sidebar">
            <div class="sidebar-header">
                <h2>Painel Admin</h2>
                <p>Bem-vinda, <?php echo htmlspecialchars($_SESSION['usuario']['nome']); ?></p>
            </div>
            
            <nav class="admin-menu">
                <a href="#" class="menu-item active" data-section="dashboard">
                    <span class="menu-icon">📊</span>
                    Dashboard
                </a>
                
                <!-- Submenu de Gerenciamento -->
                <div class="menu-group">
                    <a href="#" class="menu-item menu-toggle">
                        <span class="menu-icon">⚙️</span>
                        Gerenciamento
                        <span class="menu-arrow">▼</span>
                    </a>
                    <div class="submenu">
                        <a href="#" class="menu-item submenu-item" data-section="produtos">
                            <span class="menu-icon">📦</span>
                            Produtos
                        </a>
                        <a href="#" class="menu-item submenu-item" data-section="usuarios">
                            <span class="menu-icon">👥</span>
                            Usuários
                        </a>
                        <a href="#" class="menu-item submenu-item" data-section="feedbacks">
                            <span class="menu-icon">💬</span>
                            Feedbacks
                        </a>
                    </div>
                </div>
                
                <hr>
                <a href="/aryloja/index.php" class="menu-item">
                    <span class="menu-icon">👁️</span>
                    Ver Catálogo
                </a>
                <a href="/aryloja/app/routes/logout.php" class="menu-item logout">
                    <span class="menu-icon">🚪</span>
                    Sair
                </a>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="admin-main">
            <header class="admin-header">
                <h1>Painel de Administração - Ary Bordados</h1>
                <p>Gerencie seus produtos, usuários e feedbacks</p>
            </header>

            <div class="admin-content">
                <!-- Dashboard Section -->
                <section id="dashboard" class="admin-section active">
                    <div class="dashboard-grid">
                        <div class="dashboard-card" onclick="mostrarSecao('produtos')" style="cursor: pointer;">
                            <h3>📦 Total de Produtos</h3>
                            <p id="totalProdutos" class="dashboard-number">0</p>
                        </div>
                        <div class="dashboard-card" onclick="mostrarSecao('usuarios')" style="cursor: pointer;">
                            <h3>👥 Total de Usuários</h3>
                            <p id="totalUsuarios" class="dashboard-number">0</p>
                        </div>
                        <div class="dashboard-card" onclick="mostrarSecao('feedbacks')" style="cursor: pointer;">
                            <h3>💬 Total de Feedbacks</h3>
                            <p id="totalFeedbacks" class="dashboard-number">0</p>
                        </div>
                    </div>
                </section>

                <!-- Produtos Section -->
                <section id="produtos" class="admin-section">
                    <div class="section-header">
                        <h2>Gerenciar Produtos</h2>
                        <button class="btn-primary" onclick="abrirFormularioProduto()">+ Novo Produto</button>
                    </div>

                    <!-- Formulário de Produto -->
                    <div id="formProdutoContainer" class="form-container" style="display: none;">
                        <form id="formProduto" enctype="multipart/form-data" onsubmit="salvarProduto(event)">
                            <h3 id="formProdutoTitulo">Adicionar Novo Produto</h3>
                            
                            <input type="hidden" id="produtoId" name="id" value="">
                            
                            <div class="form-group">
                                <label for="produtoNome">Nome do Produto</label>
                                <input type="text" id="produtoNome" name="nome" required>
                            </div>

                            <div class="form-group">
                                <label for="produtoDescricao">Descrição</label>
                                <textarea id="produtoDescricao" name="descricao" rows="4" required></textarea>
                            </div>

                            <div class="form-row">
                                <div class="form-group">
                                    <label for="produtoPreco">Preço (R$)</label>
                                    <input type="number" id="produtoPreco" name="preco" step="0.01" required>
                                </div>

                                <div class="form-group">
                                    <label for="produtoEstoque">Estoque</label>
                                    <input type="number" id="produtoEstoque" name="estoque" required>
                                </div>

                                <div class="form-group">
                                    <label for="produtoCategoria">Categoria</label>
                                    <input type="text" id="produtoCategoria" name="categoria" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="produtoImagem">Imagem (arquivo)</label>
                                <input type="file" id="produtoImagem" name="imagem_file" accept="image/*">
                            </div>

                            <div class="form-actions">
                                <button type="submit" class="btn-primary">Salvar Produto</button>
                                <button type="button" class="btn-secondary" onclick="fecharFormularioProduto()">Cancelar</button>
                            </div>
                        </form>
                    </div>

                    <!-- Lista de Produtos -->
                    <div id="listaProdutos" class="products-list">
                        <p class="loading">Carregando produtos...</p>
                    </div>
                </section>

                <!-- Usuários Section -->
                <section id="usuarios" class="admin-section">
                    <div class="section-header">
                        <h2>Gerenciar Usuários</h2>
                    </div>

                    <div id="listaUsuarios" class="users-list">
                        <p class="loading">Carregando usuários...</p>
                    </div>
                </section>

                <!-- Feedbacks Section -->
                <section id="feedbacks" class="admin-section">
                    <div class="section-header">
                        <h2>Gerenciar Feedbacks</h2>
                    </div>

                    <div id="listaFeedbacks" class="feedbacks-list">
                        <p class="loading">Carregando feedbacks...</p>
                    </div>
                </section>
            </div>
        </main>
    </div>

    <!-- Modal de Confirmação -->
    <div id="modalConfirm" class="modal" style="display: none;">
        <div class="modal-content">
            <h3>Confirmação</h3>
            <p id="modalMessage"></p>
            <div class="modal-actions">
                <button id="modalConfirmBtn" class="btn-primary">Confirmar</button>
                <button class="btn-secondary" onclick="fecharModal()">Cancelar</button>
            </div>
        </div>
    </div>

    <script src="/aryloja/public/assets/js/app.js"></script>
    <script src="/aryloja/public/assets/js/admin.js"></script>
</body>
</html>