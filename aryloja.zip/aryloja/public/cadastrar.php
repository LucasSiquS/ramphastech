<?php require_once __DIR__ . '/../view/helpers/header.php'; ?>

<link rel="stylesheet" href="../public/assets/css/cadastrar.css">

<section class="hero">
  <h1>Cadastrar</h1>
  <p>Crie sua conta para efetuar seus pedidos.</p>
</section>

<section class="register-section">
  <div class="register-box">
    <h2>Preencha seus dados</h2>
    <form id="form-register">
      <div class="form-group">
        <label>Nome:</label>
        <input type="text" name="nome" required />
      </div>
      <div class="form-group">
        <label>Email:</label>
        <input type="email" name="email" required />
      </div>
      <div class="form-group">
        <label>Senha:</label>
        <input type="password" name="senha" required minlength="6" />
      </div>
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>" />
      <button type="submit">Cadastrar</button>
      <div class="login-link">
        <p>Já tem conta? <a href="/login.php">Entrar</a></p>
      </div>
      <p id="register-msg" class="msg"></p>
    </form>
  </div>
</section>

<script>
document.getElementById('form-register').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  fd.append('acao', 'cadastrar');
  
  try {
    const res = await fetch('/aryloja/app/routes/usuario_ajax.php', {
      method: 'POST',
      body: fd
    });
    
    const data = await res.json();
    const msg = document.getElementById('register-msg');
    
    if (data && data.success) {
      msg.textContent = 'Cadastro realizado! Você já pode entrar.';
      msg.style.color = 'green';
      setTimeout(() => window.location.href = '/aryloja/public/login.php', 800);
    } else {
      msg.textContent = data.error || 'Erro ao cadastrar (email já existe?)';
      msg.style.color = 'red';
    }
  } catch (err) {
    const msg = document.getElementById('register-msg');
    msg.textContent = 'Erro de rede: ' + err.message;
    msg.style.color = 'red';
  }
});
</script>

<?php require_once __DIR__ . '/../view/helpers/footer.php'; ?>