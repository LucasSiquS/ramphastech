async function handleLogin(event) {
    event.preventDefault();
    
    const form = document.getElementById('loginForm');
    const email = form.querySelector('input[name="email"]').value;
    const senha = form.querySelector('input[name="senha"]').value;
    
    try {
        const fd = new FormData();
        fd.append('acao', 'login');
        fd.append('email', email);
        fd.append('senha', senha);
        
        const response = await fetch('/aryloja/app/routes/usuario_ajax.php', {
            method: 'POST',
            body: fd
        });
        
        const data = await response.json();
        
        console.log('Resposta do servidor:', data);
        
        if (data.success) {
            alert('Login realizado com sucesso!');
            
            // Redirecionar para admin se for chefeary@gmail.com
            if (data.usuario && data.usuario.email === 'chefeary@gmail.com') {
                window.location.href = '/aryloja/public/admin.php';
            } else {
                window.location.href = '/aryloja/index.php';
            }
        } else {
            alert('Erro: ' + (data.error || 'Login falhou'));
        }
    } catch (e) {
        alert('Erro de rede: ' + e.message);
    }
}
