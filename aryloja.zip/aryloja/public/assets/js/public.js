

async function listarProdutos() {
    const fd = new FormData();
    fd.append('acao', 'listar');
    const res = await ajaxForm('/aryloja/app/routes/produto_ajax.php', fd);
    console.log(res)
    const grid = document.getElementById('produtos-grid');
    grid.innerHTML = '';
    (res || []).forEach(p => {
      const card = document.createElement('div');
      card.className = 'product-card';
      const imgSrc = p.imagem ? '/aryloja/public/uploads/' + htmlescape(p.imagem) : '';
      const imageHTML = imgSrc 
        ? `<img src="${imgSrc}" alt="${htmlescape(p.nome)}" onerror="this.parentElement.innerHTML='<p style=\'text-align:center; padding: 20px;\'>Sem Imagem</p>'">`
        : `<p style='text-align:center; padding: 20px; color: #999;'>Sem Imagem</p>`;
      
      const temEstoque = parseInt(p.estoque) > 0;
      const botaoHTML = temEstoque
        ? `<button class="btn" data-id="${p.id_produto}">Adicionar ao Carrinho</button>`
        : `<button class="btn" disabled style="background-color: #ccc; cursor: not-allowed;">Fora do Estoque</button>`;
      
      card.innerHTML = `
        <div class="product-image">${imageHTML}</div>
        <div class="product-info">
          <h3 class="product-title">${htmlescape(p.nome)}</h3>
          <p class="product-description">${htmlescape(p.descricao || '')}</p>
          <div class="product-price">R$ ${Number(p.preco).toFixed(2)}</div>
          ${botaoHTML}
        </div>`;
      
      if (temEstoque) {
        card.querySelector('button').addEventListener('click', () => adicionarAoCarrinho(p.id_produto));
      }
      grid.appendChild(card);
    });
  }
  
  async function adicionarAoCarrinho(id) {
    const fd = new FormData();
    fd.append('acao', 'adicionar');
    fd.append('id_produto', id);
    fd.append('qtd', 1);
    fd.append('csrf_token', csrfToken());
    const res = await ajaxForm('/aryloja/app/routes/carrinho_ajax.php', fd);
    if (!res) {
      alert('Erro ao adicionar: resposta vazia do servidor');
      return;
    }

    if (res.success) {
      alert(res.message || 'Produto adicionado!');
      return;
    }

    // Quando erro, mostrar mensagem retornada pelo servidor.
    const err = res.error || 'Erro ao adicionar';
    alert(err);

    // Se erro for por falta de login, redirecionar para o login automaticamente
    if (/logado/i.test(err) || /precisa estar logad/i.test(err)) {
      // dar tempo para o usuário ver o alerta e então redirecionar
      setTimeout(() => { window.location.href = '/aryloja/public/login.php'; }, 500);
    }
  }
  
  async function listarCarrinho() {
    // Implementar lógica para listar itens do carrinho via AJAX
  }

  // Funções de Feedback
  async function carregarFeedbacks() {
    const fd = new FormData();
    fd.append('acao', 'listar');
    
    try {
      const res = await fetch('/aryloja/app/routes/feedback_ajax.php', {
        method: 'POST',
        body: fd
      });
      const feedbacks = await res.json();
      
      const container = document.getElementById('feedbacks-container');
      if (!container) return;
      
      container.innerHTML = '';
      
      if (!feedbacks || feedbacks.length === 0) {
        container.innerHTML = '<p class="no-feedbacks">Nenhum comentário ainda. Seja o primeiro a comentar!</p>';
        return;
      }
      
      feedbacks.forEach(feedback => {
        const div = document.createElement('div');
        div.className = 'feedback-item';
        
        const data = new Date(feedback.data_criacao);
        const dataFormatada = data.toLocaleDateString('pt-BR') + ' às ' + data.toLocaleTimeString('pt-BR');
        
        const autor = feedback.usuario_nome || feedback.usuario || 'Anônimo';
        div.innerHTML = `
          <p class="feedback-text">"${htmlescape(feedback.comentario)}"</p>
          <p class="feedback-author">— ${htmlescape(autor)}</p>
          <p class="feedback-date">${dataFormatada}</p>
        `;
        
        container.appendChild(div);
      });
    } catch (err) {
      console.error('Erro ao carregar feedbacks:', err);
    }
  }

  function enviarFeedback(event) {
    event.preventDefault();
    
    const comentario = document.getElementById('comentario').value.trim();
    
    if (!comentario) {
      alert('Por favor, digite um comentário!');
      return;
    }
    
    const fd = new FormData();
    fd.append('acao', 'salvar');
    fd.append('comentario', comentario);
    fd.append('csrf_token', csrfToken());
    
    fetch('/aryloja/app/routes/feedback_ajax.php', {
      method: 'POST',
      body: fd
    })
    .then(res => res.json())
    .then(data => {
      const msg = document.getElementById('feedback-message');
      
      if (data.success) {
        msg.textContent = 'Comentário enviado com sucesso!';
        msg.className = 'feedback-message success';
        document.getElementById('feedbackForm').reset();
        document.getElementById('charCount').textContent = '0/300';
        
        // Recarregar feedbacks após 1 segundo
        setTimeout(() => {
          carregarFeedbacks();
          msg.textContent = '';
        }, 1000);
      } else {
        msg.textContent = data.error || 'Erro ao enviar comentário';
        msg.className = 'feedback-message error';
      }
    })
    .catch(err => {
      console.error('Erro:', err);
      const msg = document.getElementById('feedback-message');
      msg.textContent = 'Erro ao enviar comentário';
      msg.className = 'feedback-message error';
    });
  }

  // Contador de caracteres
  document.addEventListener('DOMContentLoaded', () => {
    const textarea = document.getElementById('comentario');
    if (textarea) {
      textarea.addEventListener('input', function() {
        document.getElementById('charCount').textContent = this.value.length + '/300';
      });
    }
  });

  document.addEventListener('DOMContentLoaded', () => {
    console.log("test")
    console.log(listarProdutos());
    carregarFeedbacks();
  });