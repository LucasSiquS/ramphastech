

function csrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.content : '';
  }
  
  async function ajaxForm(url, formData) {
    if (!formData.has('csrf_token')) formData.append('csrf_token', csrfToken());
    try {
      const res = await fetch(url, { method: 'POST', body: formData });
      return await res.json();
    } catch (e) {
      console.error('ajaxForm error', e);
      return { success: false, error: 'Erro de rede' };
    }
  }
  
  function htmlescape(str) {
    const div = document.createElement('div');
    div.textContent = (str ?? '').toString();
    return div.innerHTML;
  }

  async function finalizarPedidoWhatsApp() {
    const fd = new FormData();
    const res = await ajaxForm('/aryloja/app/routes/gerar_pedido_whatsapp.php', fd);
    
    if (!res.success) {
      alert('Erro: ' + (res.error || 'Não foi possível gerar o pedido'));
      return;
    }
    
    const numeroWhatsApp = "5511932624664"; // SUBSTITUA PELO NÚMERO CORRETO
    const mensagem = encodeURIComponent(res.mensagem);
    window.open(`https://wa.me/${numeroWhatsApp}?text=${mensagem}`, "_blank");
  }
  
  /**
   * @param {string} email
   * @param {{maskChar?: string}} [opts]
   * @returns {string}
   */
  function maskEmail(email, opts = {}) {
    const { maskChar = '*' } = opts;
    if (email === null || email === undefined) return '';
    email = String(email).trim();


    const isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    if (!isValid) return email;

    const parts = email.match(/^([^@]+)@(.+)$/);
    const local = parts[1];
    const domain = parts[2];

    let maskedLocal;
    if (local.length === 1) {
      maskedLocal = maskChar;
    } else if (local.length === 2) {
      maskedLocal = local[0] + maskChar;
    } else {
      maskedLocal = local.replace(/^(.)(.*)(.)$/, function (_, first, middle, last) {
        return first + maskChar.repeat(Math.max(1, middle.length)) + last;
      });
    }

    return maskedLocal + '@' + domain;
  }


  window.maskEmail = maskEmail;

