async function atualizarQuantidade(index, novaQuantidade) {
    if (novaQuantidade < 1) return;
    
    const item = document.querySelector(`[data-index="${index}"]`);
    if (!item) return;
    
    const estoque = parseInt(item.dataset.estoque) || 999999;
    
    if (novaQuantidade > estoque) {
        alert(`Quantidade não disponível. Máximo em estoque: ${estoque}`);
        const inputEl = document.getElementById(`quantidade_${index}`);
        if (inputEl) inputEl.value = estoque;
        return;
    }
    
    try {
        const fd = new FormData();
        fd.append('acao', 'atualizar');
        fd.append('index', index);
        fd.append('quantidade', novaQuantidade);
        
        const response = await fetch('/aryloja/app/routes/carrinho_ajax.php', {
            method: 'POST',
            body: fd
        });
        
        const data = await response.json();
        if (data.success) {
            // Atualizar o subtotal na página
            const item = document.querySelector(`[data-index="${index}"]`);
            if (item) {
                const preco = parseFloat(item.dataset.preco);
                const subtotal = preco * novaQuantidade;
                const subtotalEl = item.querySelector('.carrinho-item-subtotal');
                if (subtotalEl) {
                    subtotalEl.textContent = `Subtotal: R$ ${subtotal.toFixed(2).replace('.', ',')}`;
                }
            }
            
            // Recalcular total
            atualizarTotal();
        } else {
            alert('Erro ao atualizar: ' + (data.error || 'Desconhecido'));
            const inputEl = document.getElementById(`quantidade_${index}`);
            if (inputEl) inputEl.value = parseInt(inputEl.value || 1);
        }
    } catch (e) {
        alert('Erro ao atualizar: ' + e.message);
    }
}

async function removerDoCarrinho(index) {
    if (!confirm('Tem certeza que quer remover?')) return;
    
    try {
        const fd = new FormData();
        fd.append('acao', 'remover');
        fd.append('id_produto', index);
        
        const response = await fetch('/aryloja/app/routes/carrinho_ajax.php', {
            method: 'POST',
            body: fd
        });
        
        const data = await response.json();
        if (data.success) {
            // Verificar se o carrinho ficou vazio
            const fd2 = new FormData();
            fd2.append('acao', 'listar');
            const listRes = await fetch('/aryloja/app/routes/carrinho_ajax.php', {
                method: 'POST',
                body: fd2
            });
            const listData = await listRes.json();
            
            // Se carrinho vazio, recarregar página
            if (Object.keys(listData).length === 0) {
                location.reload();
            } else {
                // Caso contrário, remover o elemento da página
                const item = document.querySelector(`[data-index="${index}"]`);
                if (item) {
                    item.remove();
                }
                atualizarTotal();
            }
        } else {
            alert('Erro ao remover: ' + (data.error || 'Desconhecido'));
        }
    } catch (e) {
        alert('Erro ao remover: ' + e.message);
    }
}

async function atualizarTotal() {
    try {
        const fd = new FormData();
        fd.append('acao', 'total');
        
        const response = await fetch('/aryloja/app/routes/carrinho_ajax.php', {
            method: 'POST',
            body: fd
        });
        
        const data = await response.json();
        if (data.total !== undefined) {
            const totalEl = document.querySelector('.linha-resumo.total-geral span:last-child');
            if (totalEl) {
                totalEl.textContent = `R$ ${parseFloat(data.total).toFixed(2).replace('.', ',')}`;
            }
        }
    } catch (e) {
        console.error('Erro ao atualizar total:', e);
    }
}
