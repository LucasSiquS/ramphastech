// Admin Dashboard JavaScript

let productoAtualizar = null;

// Event listeners para menu
document.addEventListener('DOMContentLoaded', function() {
    const menuItems = document.querySelectorAll('.menu-item[data-section]');
    const menuToggle = document.querySelector('.menu-toggle');
    
    // Toggle submenu
    if (menuToggle) {
        menuToggle.addEventListener('click', function(e) {
            e.preventDefault();
            const submenu = this.nextElementSibling;
            if (submenu) {
                submenu.classList.toggle('active');
                this.classList.toggle('active');
            }
        });
    }
    
    menuItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const section = this.getAttribute('data-section');
            mostrarSecao(section);
            
            // Fechar submenu após clicar
            const submenu = document.querySelector('.submenu');
            if (submenu) {
                submenu.classList.remove('active');
                const toggle = document.querySelector('.menu-toggle');
                if (toggle) {
                    toggle.classList.remove('active');
                }
            }
        });
    });

    // Carregar dados iniciais
    carregarDashboard();
});

// Função para mudar de seção
function mostrarSecao(secao) {
    // Remover seção ativa
    document.querySelectorAll('.admin-section').forEach(s => {
        s.classList.remove('active');
    });
    
    // Remover menu ativo
    document.querySelectorAll('.menu-item').forEach(m => {
        m.classList.remove('active');
    });
    
    // Ativar nova seção
    const secaoElement = document.getElementById(secao);
    if (secaoElement) {
        secaoElement.classList.add('active');
    }
    
    // Ativar menu item
    document.querySelector(`.menu-item[data-section="${secao}"]`).classList.add('active');
    
    // Carregar dados da seção
    switch(secao) {
        case 'dashboard':
            carregarDashboard();
            break;
        case 'produtos':
            carregarProdutos();
            break;
        case 'usuarios':
            carregarUsuarios();
            break;
        case 'feedbacks':
            carregarFeedbacks();
            break;
    }
}

// DASHBOARD
function carregarDashboard() {
    const fd = new FormData();
    fd.append('acao', 'stats');
    fd.append('tipo', 'dashboard');
    
    fetch('/aryloja/app/routes/admin_ajax.php', {
        method: 'POST',
        body: fd
    })
    .then(res => res.json())
    .then(data => {
        document.getElementById('totalProdutos').textContent = data.totalProdutos || 0;
        document.getElementById('totalUsuarios').textContent = data.totalUsuarios || 0;
        document.getElementById('totalFeedbacks').textContent = data.totalFeedbacks || 0;
    })
    .catch(err => console.error('Erro ao carregar dashboard:', err));
}

// PRODUTOS
function carregarProdutos() {
    const fd = new FormData();
    fd.append('acao', 'listar');
    fd.append('tipo', 'produtos');
    
    fetch('/aryloja/app/routes/admin_ajax.php', {
        method: 'POST',
        body: fd
    })
    .then(res => res.json())
    .then(produtos => {
        const container = document.getElementById('listaProdutos');
        
        if (produtos.length === 0) {
            container.innerHTML = '<p class="loading">Nenhum produto cadastrado.</p>';
            return;
        }
        
        container.innerHTML = produtos.map(produto => `
            <div class="product-card">
                ${produto.imagem ? `<img src="/aryloja/public/uploads/${produto.imagem}" alt="${htmlescape(produto.nome)}" class="product-image">` : '<div class="product-image" style="background: #ddd; display: flex; align-items: center; justify-content: center;">Sem imagem</div>'}
                <div class="product-info">
                    <h4>${htmlescape(produto.nome)}</h4>
                    <p><strong>Descrição:</strong> ${htmlescape(produto.descricao)}</p>
                    <p><strong>Preço:</strong> R$ ${parseFloat(produto.preco).toFixed(2).replace('.', ',')}</p>
                    <p><strong>Estoque:</strong> ${produto.estoque}</p>
                    <p><strong>Categoria:</strong> ${htmlescape(produto.categoria)}</p>
                </div>
                <div class="card-actions">
                    <button class="btn-edit" onclick="editarProduto(${produto.id_produto})">Editar</button>
                    <button class="btn-delete" onclick="confirmarExclusaoProduto(${produto.id_produto}, '${htmlescape(produto.nome)}')">Excluir</button>
                </div>
            </div>
        `).join('');
    })
    .catch(err => console.error('Erro ao carregar produtos:', err));
}

function abrirFormularioProduto() {
    productoAtualizar = null;
    document.getElementById('produtoId').value = '';
    document.getElementById('formProduto').reset();
    document.getElementById('formProdutoTitulo').textContent = 'Adicionar Novo Produto';
    document.getElementById('formProdutoContainer').style.display = 'block';
}

function fecharFormularioProduto() {
    document.getElementById('formProdutoContainer').style.display = 'none';
    productoAtualizar = null;
}

function editarProduto(id) {
    const fd = new FormData();
    fd.append('acao', 'listar');
    fd.append('tipo', 'produtos');
    
    fetch('/aryloja/app/routes/admin_ajax.php', {
        method: 'POST',
        body: fd
    })
    .then(res => res.json())
    .then(produtos => {
        const produto = produtos.find(p => p.id_produto == id);
        if (produto) {
            productoAtualizar = produto;
            document.getElementById('produtoId').value = produto.id_produto;
            document.getElementById('produtoNome').value = produto.nome;
            document.getElementById('produtoDescricao').value = produto.descricao;
            document.getElementById('produtoPreco').value = produto.preco;
            document.getElementById('produtoEstoque').value = produto.estoque;
            document.getElementById('produtoCategoria').value = produto.categoria;
            document.getElementById('formProdutoTitulo').textContent = 'Editar Produto';
            document.getElementById('formProdutoContainer').style.display = 'block';
        }
    })
    .catch(err => console.error('Erro ao carregar produto:', err));
}

function salvarProduto(event) {
    event.preventDefault();
    
    const form = document.getElementById('formProduto');
    const fd = new FormData(form);
    
    const id = document.getElementById('produtoId').value;
    if (id) {
        fd.append('acao', 'atualizar');
    } else {
        fd.append('acao', 'cadastrar');
    }
    fd.append('tipo', 'produtos');
    
    fetch('/aryloja/app/routes/admin_ajax.php', {
        method: 'POST',
        body: fd
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert('Produto salvo com sucesso!');
            fecharFormularioProduto();
            carregarProdutos();
        } else {
            alert('Erro ao salvar produto');
        }
    })
    .catch(err => {
        console.error('Erro:', err);
        alert('Erro ao salvar produto');
    });
}

function confirmarExclusaoProduto(id, nome) {
    const modal = document.getElementById('modalConfirm');
    document.getElementById('modalMessage').textContent = `Tem certeza que deseja excluir o produto "${nome}"?`;
    document.getElementById('modalConfirmBtn').onclick = () => excluirProduto(id);
    modal.style.display = 'flex';
}

function excluirProduto(id) {
    const fd = new FormData();
    fd.append('acao', 'excluir');
    fd.append('tipo', 'produtos');
    fd.append('id', id);
    
    fetch('/aryloja/app/routes/admin_ajax.php', {
        method: 'POST',
        body: fd
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert('Produto excluído com sucesso!');
            fecharModal();
            carregarProdutos();
        } else {
            alert('Erro ao excluir produto');
        }
    })
    .catch(err => console.error('Erro:', err));
}

// USUÁRIOS
function carregarUsuarios() {
    const fd = new FormData();
    fd.append('acao', 'listar');
    fd.append('tipo', 'usuarios');
    
    fetch('/aryloja/app/routes/admin_ajax.php', {
        method: 'POST',
        body: fd
    })
    .then(res => res.json())
    .then(usuarios => {
        const container = document.getElementById('listaUsuarios');
        
        if (usuarios.length === 0) {
            container.innerHTML = '<p class="loading">Nenhum usuário cadastrado.</p>';
            return;
        }
        
        container.innerHTML = usuarios.map(usuario => `
            <div class="user-card">
                <div class="user-info">
                    <h4>${htmlescape(usuario.nome)}</h4>
                    <p><strong>Email:</strong> ${htmlescape(usuario.email)}</p>
                    <p><strong>Permissão:</strong> ${usuario.permissao === 'admin' ? '👤 Administrador' : '👥 Usuário'}</p>
                    <p><strong>Cadastrado em:</strong> ${new Date(usuario.data_cadastro).toLocaleDateString('pt-BR')}</p>
                </div>
                <div class="card-actions">
                    ${usuario.email !== 'chefeary@gmail.com' ? `<button class="btn-delete" onclick="confirmarExclusaoUsuario(${usuario.id_usuario}, '${htmlescape(usuario.nome)}')">Excluir</button>` : '<span style="color: #999; font-size: 0.9rem;">Você não pode excluir sua própria conta</span>'}
                </div>
            </div>
        `).join('');
    })
    .catch(err => console.error('Erro ao carregar usuários:', err));
}

function confirmarExclusaoUsuario(id, nome) {
    const modal = document.getElementById('modalConfirm');
    document.getElementById('modalMessage').textContent = `Tem certeza que deseja excluir o usuário "${nome}"?`;
    document.getElementById('modalConfirmBtn').onclick = () => excluirUsuario(id);
    modal.style.display = 'flex';
}

function excluirUsuario(id) {
    const fd = new FormData();
    fd.append('acao', 'excluir');
    fd.append('tipo', 'usuarios');
    fd.append('id', id);
    
    fetch('/aryloja/app/routes/admin_ajax.php', {
        method: 'POST',
        body: fd
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert('Usuário excluído com sucesso!');
            fecharModal();
            carregarUsuarios();
        } else {
            alert('Erro ao excluir usuário');
        }
    })
    .catch(err => console.error('Erro:', err));
}

// FEEDBACKS
function carregarFeedbacks() {
    const fd = new FormData();
    fd.append('acao', 'listar');
    fd.append('tipo', 'feedbacks');
    
    fetch('/aryloja/app/routes/admin_ajax.php', {
        method: 'POST',
        body: fd
    })
    .then(res => res.json())
    .then(feedbacks => {
        const container = document.getElementById('listaFeedbacks');
        
        if (feedbacks.length === 0) {
            container.innerHTML = '<p class="loading">Nenhum feedback cadastrado.</p>';
            return;
        }
        
        container.innerHTML = feedbacks.map(feedback => `
            <div class="feedback-card">
                <div class="feedback-info">
                    <h4>Feedback #${feedback.id}</h4>
                    <p>${htmlescape(feedback.comentario)}</p>
                    <p><strong>Data:</strong> ${new Date(feedback.data_criacao).toLocaleDateString('pt-BR')} ${new Date(feedback.data_criacao).toLocaleTimeString('pt-BR')}</p>
                </div>
                <div class="card-actions">
                    <button class="btn-delete" onclick="confirmarExclusaoFeedback(${feedback.id})">Excluir</button>
                </div>
            </div>
        `).join('');
    })
    .catch(err => console.error('Erro ao carregar feedbacks:', err));
}

function confirmarExclusaoFeedback(id) {
    const modal = document.getElementById('modalConfirm');
    document.getElementById('modalMessage').textContent = `Tem certeza que deseja excluir este feedback?`;
    document.getElementById('modalConfirmBtn').onclick = () => excluirFeedback(id);
    modal.style.display = 'flex';
}

function excluirFeedback(id) {
    const fd = new FormData();
    fd.append('acao', 'excluir');
    fd.append('tipo', 'feedbacks');
    fd.append('id', id);
    
    fetch('/aryloja/app/routes/admin_ajax.php', {
        method: 'POST',
        body: fd
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert('Feedback excluído com sucesso!');
            fecharModal();
            carregarFeedbacks();
        } else {
            alert('Erro ao excluir feedback');
        }
    })
    .catch(err => console.error('Erro:', err));
}

// Modal
function fecharModal() {
    document.getElementById('modalConfirm').style.display = 'none';
}

// Fechar modal ao clicar fora
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('modalConfirm');
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            fecharModal();
        }
    });
});

// Helper function para escapar HTML
function htmlescape(str) {
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}