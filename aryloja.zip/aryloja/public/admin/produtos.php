
<?php require_once __DIR__ . '/../../view/helpers/header.php'; ?>
/assets/css/adminprod.css

<section class="container">
  <h2>Gerenciamento de Produtos</h2>
  <div class="tab-navigation">
    <button class="tab-button active" data-tab="tab-cadastrar">Cadastrar Produto</button>
    <button class="tab-button" data-tab="tab-lista">Lista de Produtos</button>
  </div>

  <div id="tab-cadastrar" class="tab-content active">
    <form id="form-produto" enctype="multipart/form-data">
      <input type="hidden" name="id" />
      <div class="form-group">
        <label>Nome:</label>
        <input type="text" name="nome" required />
      </div>
      <div class="form-group">
        <label>Descrição:</label>
        <textarea name="descricao"></textarea>
      </div>
      <div class="form-group">
        <label>Preço:</label>
        <input type="number" step="0.01" name="preco" required />
      </div>
      <div class="form-group">
        <label>Estoque:</label>
        <input type="number" name="estoque" required />
      </div>
      <div class="form-group">
        <label>Categoria:</label>
        <input type="text" name="categoria" />
      </div>
      <div class="form-group">
        <label>Imagem:</label>
        <input type="file" name="imagem_file" accept="image/*" />
      </div>
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>" />
      <button type="submit" class="btn">Salvar</button>
      <button type="button" id="btn-limpar" class="btn btn-secondary">Limpar</button>
      <p id="produto-msg" class="msg"></p>
    </form>
  </div>

  <div id="tab-lista" class="tab-content">
    <table>
      <thead>
        <tr>
          <th>Imagem</th><th>Nome</th><th>Preço</th><th>Estoque</th><th>Ações</th>
        </tr>
      </thead>
      <tbody id="tbody-produtos"></tbody>
    </table>
  </div>
</section>

<script src="/aryloja/public/assets/js/app.js"></script>
<script>
async function listarProdutosAdmin() {
  const fd = new FormData();
  fd.append('acao', 'listar');
  const res = await ajaxForm('/aryloja/app/routes/produto_ajax.php', fd);
  const tbody = document.getElementById('tbody-produtos');
  tbody.innerHTML = '';
  if (!res || !Array.isArray(res) || res.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5">Nenhum produto cadastrado</td></tr>';
    return;
  }
  res.forEach(p => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><img src="/aryloja/public/uploads/${p.imagem || 'default.jpg'}" alt="${htmlescape(p.nome)}" style="max-width: 50px; max-height: 50px;"></td>
      <td>${htmlescape(p.nome)}</td>
      <td>R$ ${parseFloat(p.preco).toFixed(2).replace('.', ',')}</td>
      <td>${p.estoque}</td>
      <td>
        <button onclick="editarProdutoAdmin(${p.id_produto})" class="btn">Editar</button>
        <button onclick="excluirProdutoAdmin(${p.id_produto})" class="btn btn-danger">Excluir</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function editarProdutoAdmin(id) {
  const fd = new FormData();
  fd.append('acao', 'listar');
  ajaxForm('/aryloja/app/routes/produto_ajax.php', fd).then(res => {
    const produto = res.find(p => p.id_produto == id);
    if (produto) {
      document.querySelector('#form-produto [name=id]').value = produto.id_produto;
      document.querySelector('#form-produto [name=nome]').value = produto.nome;
      document.querySelector('#form-produto [name=descricao]').value = produto.descricao;
      document.querySelector('#form-produto [name=preco]').value = produto.preco;
      document.querySelector('#form-produto [name=estoque]').value = produto.estoque;
      document.querySelector('#form-produto [name=categoria]').value = produto.categoria;
      document.querySelectorAll('.tab-button')[0].click();
    }
  });
}

function excluirProdutoAdmin(id) {
  if (confirm('Tem certeza?')) {
    const fd = new FormData();
    fd.append('acao', 'excluir');
    fd.append('id', id);
    ajaxForm('/aryloja/app/routes/produto_ajax.php', fd).then(res => {
      if (res.success) {
        alert('Produto excluído!');
        listarProdutosAdmin();
      }
    });
  }
}

document.querySelectorAll('.tab-button').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-button').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(btn.dataset.tab).classList.add('active');
  });
});

document.addEventListener('DOMContentLoaded', () => {
  listarProdutosAdmin();
});

document.getElementById('form-produto').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const id = fd.get('id');
  fd.append('acao', id ? 'atualizar' : 'cadastrar');
  const res = await ajaxForm('/aryloja/app/routes/produto_ajax.php', fd);
  const msg = document.getElementById('produto-msg');
  msg.textContent = res && res.success ? 'Produto salvo!' : (res.error || 'Erro ao salvar');
  if (res.success) {
    e.target.reset();
    listarProdutosAdmin();
  }
});

document.getElementById('btn-limpar').addEventListener('click', () => {
  document.getElementById('form-produto').reset();
  document.querySelector('#form-produto [name=id]').value = '';
});
</script>

<?php require_once __DIR__ . '/../../view/helpers/footer.php'; ?>
