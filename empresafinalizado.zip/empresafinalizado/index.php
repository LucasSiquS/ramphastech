<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ramphastech</title>
    <link href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@400;700&display=swap" rel="stylesheet">
    <link rel="shortcut icon" type="img/pagina.png" href="./img/pagina.png">
    <style>
        body {
            font-family: 'League Spartan', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #fffff6;
            transition: background-color 0.3s, color 0.3s;
        }
        body.dark-mode {
            background-color: #1e1e1e;
            color: #f0f0f0;
        }
        .navbar {
            background-color: #0197b2;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px 30px;
        }
        .logo-text {
            font-size: 35px;
            font-weight: 700;
            color: black;
        }
        .nav-links {
            list-style: none;
            display: flex;
            gap: 20px;
        }
        .nav-links a {
            font-size: 22px;
            font-weight: 600;
            text-decoration: none;
            color: black;
            padding: 5px;
            border-bottom: 2px solid transparent;
            transition: border-bottom 0.3s ease-in-out;
        }
        .nav-links a:hover {
            border-bottom: 2px solid black;
        }
        .logo {
            width: 75px;
            height: 75px;
        }
        .theme-toggle {
            padding: 10px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            background-color: #fff;
        }
        .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 50px;
        }
        .text-section {
            max-width: 60%;
            margin-left: 7vw;
        }
        .text-section h1 {
            font-size: 60px;
            font-weight: 700;
        }
        .text-section p {
            font-size: 30px;
            line-height: 1.6;
        }
        .image-section img {
            max-width: 400px;
            margin-right: 6vw;
        }
        .ideals-section {
            text-align: center;
            padding: 40px;
        }
        .ideals-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }
        .row {
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        .ideal-box {
            width: 26vw;
            border: 2px solid #ccc;
            border-radius: 20px;
            padding: 20px;
            box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.1);
            font-size: 20px;
        }
        .ideal-box p {
            text-align: justify;
        }
        .ideal-box-value {
            width: 56vw;
            border: 2px solid #ccc;
            border-radius: 20px;
            padding: 20px;
            box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.1);
            font-size: 20px;
        }
        .ideal-box-value p {
            text-align: justify;
        }
        .ideal-box h2 {
            font-size: 28px;
            font-weight: 700;
        }
        .footer-content {
            text-align: center;
            padding: 20px;
            background-color: #0097b2;
            color: #000000;
            font-size: large;
        }
        #contato {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }
        .contact-content {
            width: 56vw;
            border: 2px solid #ccc;
            border-radius: 20px;
            padding: 20px;
            box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.1);
            font-size: 20px;
            margin-bottom: 5vw;
            text-align: center;
            background-color: #0097b2;
        }
        .form label,
        .form input,
        .form textarea,
        .form button {
            display: block;
            width: 98%;
            margin: 10px 0;
        }
        .form label {
            color: #000000;
        }
        .form input,
        .form textarea {
            font: inherit;
            padding: 0.8rem;
            margin-bottom: 1rem;
            border: 1px solid;
            border-radius: 8px;
        }
        .form textarea {
            min-height: 13rem;
            resize: vertical;
        }
        .form button {
            padding: 1rem;
            background: #fffff6;
            color: #000;
            text-transform: uppercase;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }
        .main-content {
            display: none;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {
            $(".main-content").fadeIn(800);

            $("#contact-form").submit(function (e) {
                e.preventDefault();
                $.ajax({
                    url: "https://formsubmit.co/ajax/tcc.4info2025@gmail.com",
                    method: "POST",
                    data: $(this).serialize(),
                    dataType: "json",
                    success: function () {
                        alert("Mensagem enviada com sucesso! 🚀");
                        $("#contact-form")[0].reset();
                    },
                    error: function (xhr, status, error) {
                        alert("Ocorreu um erro 😵: " + error);
                    }
                });
            });

            $("#theme-toggle").click(function () {
                $("body").toggleClass("dark-mode");
            });
        });
    </script>
</head>
<body>
    <header class="navbar">
        <div class="logo-text">Ramphastech</div>
        <ul class="nav-links">
            <li><a href="#inicio">Início</a></li>
            <li><a href="equipe.php">Equipe</a></li>
            <li><a href="#ideais">Ideais</a></li>
            <li><a href="#contato">Contato</a></li>
        </ul>
        <button class="theme-toggle" id="theme-toggle">🌙</button>
        <img src="img/pagina.png" alt="Logo Tucano" class="logo">
    </header>

    <div class="main-content">
        <div id="inicio" class="container">
            <div class="text-section">
                <h1>BEM VINDE AO RAMPHASTECH!</h1>
                <p>Desenvolvemos sistemas para a internet sob demanda, priorizando inovação, acessibilidade e eficiência. Com ética e transparência, buscamos soluções que agreguem valor, promovam inclusão digital e atendam às necessidades de nossos clientes.</p>
            </div>
            <div class="image-section">
                <img src="img/page.png" alt="Imagem Ramphastech">
            </div>
        </div>

        <div id="ideais" class="ideals-section">
            <h1>NOSSOS IDEAIS:</h1>
            <div class="ideals-container">
                <div class="row">
                    <div class="ideal-box">
                        <h2>MISSÃO:</h2>
                        <p>Nossa missão é desenvolver sistemas para a internet sob demanda, oferecendo soluções práticas e eficientes de acordo com a necessidade do cliente. Comprometemo-nos a oferecer excelência em cada projeto, mantendo sempre uma postura ética, profissional e transparente, garantindo que as soluções implementadas agreguem valor real aos nossos parceiros e usuários finais.</p>
                    </div>
                    <div class="ideal-box">
                        <h2>VISÃO:</h2>
                        <p>Nossa visão como empresa é proporcionar acessibilidade para todos os públicos, através de inovações tecnológicas inclusivas. Estamos empenhados em promover a inclusão digital por meio de inovações que ultrapassam barreiras tecnológicas e sociais, contribuindo para um mundo mais justo, equitativo e conectado.</p>
                    </div>
                </div>
                <div class="ideal-box-value">
                    <h2>VALORES:</h2>
                    <p><b>Inclusão:</b> Acreditamos que a tecnologia deve ser acessível para todos, independentemente de suas limitações físicas, cognitivas ou sociais.<br><br>
                    <b>Inovação:</b> Valorizamos a criatividade e a inovação contínua, buscando sempre novas formas de aprimorar os sistemas que desenvolvemos.<br>
                    <b>Responsabilidade:</b> Atuamos com ética e transparência em todas as nossas ações, respeitando nossos clientes, colaboradores e parceiros, e promovendo práticas sustentáveis que minimizem o impacto ambiental.<br><br>
                    <b>Diversidade:</b> Valorizamos a diversidade sociocultural e buscamos sempre um ambiente inclusivo onde diferentes perspectivas sejam ouvidas e respeitadas.<br><br>
                    <b>Compromisso com o cliente:</b> Colocamos as necessidades do cliente em primeiro lugar, oferecendo soluções personalizadas aos seus objetivos e desafios.<br><br>
                    <b>Integridade:</b> Agimos com honestidade e comprometimento, mantendo a transparência em todas as nossas relações e respeitando os princípios éticos da empresa.</p>
                </div>
            </div>
        </div>

        <div id="contato">
            <div class="contact-content">
                <h1>CONTATO:</h1>
                <p>Se você deseja entrar em contato conosco, preencha o formulário abaixo e entraremos em contato o mais breve possível.</p>
                <div class="form">
                    <form id="contact-form">
                        Nome
                        <input type="text" name="name" placeholder="Se identifique." required>
                        Deixe sua mensagem
                        <p>Deixe também uma forma de contato ao fim do comentário, um email de preferência.</p>
                        <textarea name="message" placeholder="Escreva aqui sua mensagem."></textarea><br>
                        <button type="submit">Enviar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <div class="footer-content">
            <p>&copy; 2025 Ramphastech. Todos os direitos reservados.</p>
            <img src="img/rodape.png" alt="Logo Tucano" class="logo">
        </div>
    </footer>
</body>
</html>