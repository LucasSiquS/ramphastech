<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ramphastech</title>
    <link href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@400;700&display=swap" rel="stylesheet">
    <link rel="shortcut icon" type="img/pagina.png" href="./img/pagina.png">
    <style>
        body {
            font-family: 'League Spartan', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #fffff6;
            transition: background-color 0.3s, color 0.3s;
        }
        .dark-mode {
            background-color: #1e1e1e;
            color: #f0f0f0;
        }
        .navbar {
            background-color: #0197b2;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px 30px;
        }
        .logo-text {
            font-size: 35px;
            font-weight: 700;
            color: black;
        }
        .nav-links {
            list-style: none;
            display: flex;
            gap: 20px;
        }
        .nav-links a {
            font-size: 22px;
            font-weight: 600;
            text-decoration: none;
            color: black;
            padding: 5px;
            border-bottom: 2px solid transparent;
            transition: border-bottom 0.3s ease-in-out;
        }
        .nav-links a:hover {
            border-bottom: 2px solid black;
        }
        .logo {
            width: 75px;
            height: 75px;
        }
        .footer-content{
            text-align: center;
            padding: 20px;
            background-color: #0097b2;
            color: #000000;
            font-size: large;
        }
        .equipe-container {
            text-align: center;
            padding: 20px;
        }
        .equipe {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }
        .pessoa {
            background-color: white;
            border: 5px solid #0197b2;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            margin-left: 2vw;
            width: 20vw;
            height: 35vw;
            opacity: 0;
            position: relative;
            top: 50px;
            transition: background-color 0.3s, color 0.3s;
        }
        .dark-mode .pessoa {
            background-color: #333;
            color: #f0f0f0;
        }
        .pessoa img {
            width: 300px;
            height: 300px;
            border-radius: 50%;
        }
        .pessoa h3 {
            margin: 10px 0 5px;
            font-size: 30px;
        }
        .pessoa p {
            font-size: 20px;
            color: #555;
            text-align: justify;
        }
        .dark-mode .pessoa p {
            color: #ccc;
        }
        .toggle-theme {
            padding: 10px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            background-color: #fff;
        }
        @media (max-width: 768px) {
            .equipe {
                flex-direction: column;
                align-items: center;
            }
        }
    </style>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $(".pessoa").each(function(index){
                $(this).delay(200 * index).animate({opacity: 1, top: "0"}, 600);
            });
        });

        function toggleTheme() {
            $("body").toggleClass("dark-mode");
        }
    </script>
</head>
<body>
    <header class="navbar">
        <div class="logo-text">Ramphastech</div>
        <ul class="nav-links">
            <li><a href="index.php">Início</a></li>
            <li><a href="equipe.php">Equipe</a></li>
            <li><a href="index.php #ideais">Ideais</a></li>
            <li><a href="index.php #contato">Contato</a></li>
        </ul>
        <button class="toggle-theme" onclick="toggleTheme()">🌙</button>
        <img src="img/pagina.png" alt="Logo Tucano" class="logo">
    </header>

    <section class="equipe-container">
        <h2>Nossa Equipe!</h2>
        <div class="equipe">
            <div class="pessoa">
                <img src="img/sara.jpeg" alt="Sara">
                <h3>Sara Ribeiro</h3>
                <p>Desenvolvedora Front-End</p>
                <p>sara.ribeiro1@aluno.ifsp.edu.br</p>
                <p>Meu nome é Sara Ribeiro e sou responsável pela parte do front-end da empresa Ramphastech.
                Me interesso muito pela questão racial e gosto muito da área das artes em especial por moda e acredito que há várias formas de perpetuar a resistência e que a tecnologia vem para potencializá-la.</p>
            </div>
            <div class="pessoa">
                <img src="img/pablo.jpeg" alt="Pablo">
                <h3>Pablo Henrique</h3>
                <p>Desenvolvedor Front-End e Back-End</p>
                <p>pablo.l@aluno.ifsp.edu.br</p>
                <p>Meu nome é Pablo Henrique e atuo tanto no front-end quanto no back-end dessa empresa, oferecendo sempre o máximo suporte em ambas as áreas. Embora eu ache a programação fascinante, também tenho um grande interesse pelas áreas da Biologia e da Gastronomia.</p>
            </div>
            <div class="pessoa">
                <img src="img/fernanda.jpeg" alt="Fernanda">
                <h3>Maria Fernanda</h3>
                <h2>Designer</h2>
                <p>Desenvolvedora Front-End</p>
                <p>f.saugo@aluno.ifsp.edu.br</p>
                <p>Meu nome é Maria Fernanda e faço parte da direção criativa e do desenvolvimento front-end. Me interesso por questões sociais, principalmente quando diz respeito à periferia e as oportunidades tecnológicas que podem contribuir para seus negócios.</p>
            </div>
            <div class="pessoa">
                <img src="img/lucas.jfif" alt="Lucas">
                <h3>Lucas Siqueira</h3>
                <h2>Gerente</h2>
                <p>Desenvolvedor Back-End</p>
                <p>siqueira.lucassilva23@gmail.com</p>
                <p>Sou o gerente da equipe responsável pela empresa Ramphastech. Tenho grandes afinidades com questões sociais, principalmente as que podem ser relacionadas com a tecnologia. Também sou um dos responsáveis pelo back-end e do controle de qualidade dos nossos projetos.</p>
            </div>
            <div class="pessoa">
                <img src="img/nuemo.jpeg" alt="Nuemo">
                <h3>Noemy Lima</h3>
                <h2>Sub-Gerente e Designer Criativo</h2>
                <p>Desenvolvedor Back-End</p>
                <p>noemy.lima@aluno.ifsp.edu.br</p>
                <p>Meu nome é Noemy Lima, mas prefiro que me chamem de Nuemo. Sou vice-gerente da empresa, faço parte da direção criativa, do controle de qualidade e também sou desenvolvedora back-end. 
                Me interesso muito por pautas de inclusão social e acredito que a tecnologia tem grande potencial para agir positivamente nesse cenário.</p>
            </div>
        </div>
    </section>

    <footer>
        <div class="footer-content">
            <p>&copy; 2025 Ramphastech. Todos os direitos reservados.</p>
            <img src="img/rodape.png" alt="Logo Tucano" class="logo">
        </div>
    </footer>
</body>
</html>